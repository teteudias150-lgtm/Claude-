// Bola Cheia FC - servidor (site + salas online). Sem dependencias: so Node 18+.
const http=require('http'),fs=require('fs'),path=require('path'),crypto=require('crypto');
const PUB=__dirname,OK=['index.html','manifest.json','icon-192.png','icon-512.png'];
const MIME={'.html':'text/html; charset=utf-8','.js':'text/javascript','.json':'application/json','.png':'image/png'};
const srv=http.createServer((req,res)=>{
  let p=decodeURIComponent(req.url.split('?')[0]);if(p==='/')p='/index.html';
  const f=path.join(PUB,path.normalize(p));
  if(path.dirname(f)!==PUB||!OK.includes(path.basename(f))){res.writeHead(404);return res.end('nao encontrado')}
  fs.readFile(f,(e,d)=>{if(e){res.writeHead(404);return res.end('nao encontrado')}
    res.writeHead(200,{'Content-Type':MIME[path.extname(f)]||'application/octet-stream','Cache-Control':'no-cache'});res.end(d)});
});
const rooms=new Map();let nid=1;
function frame(s){const b=Buffer.from(s);let h;
  if(b.length<126)h=Buffer.from([0x81,b.length]);
  else if(b.length<65536){h=Buffer.alloc(4);h[0]=0x81;h[1]=126;h.writeUInt16BE(b.length,2)}
  else{h=Buffer.alloc(10);h[0]=0x81;h[1]=127;h.writeBigUInt64BE(BigInt(b.length),2)}
  return Buffer.concat([h,b])}
function send(c,o){if(c.dead)return;try{c.sock.write(frame(JSON.stringify(o)))}catch(e){}}
function bcast(r){const list=[...r].map(c=>({id:c.id,pres:c.pres}));r.forEach(c=>send(c,{t:'peers',list}))}
function handle(c,s){let m;try{m=JSON.parse(s)}catch(e){return}
  if(m.t==='join'&&typeof m.room==='string'&&m.room.length<=64){
    if(c.room){c.room.delete(c);if(!c.room.size)rooms.delete(c.rn);else bcast(c.room)}
    c.rn=m.room;c.pres={};let r=rooms.get(c.rn);if(!r){r=new Set();rooms.set(c.rn,r)}
    r.add(c);c.room=r;bcast(r)}
  else if(m.t==='pres'&&c.room&&m.p&&typeof m.p==='object'){
    for(const k of Object.keys(m.p).slice(0,10))c.pres[k]=m.p[k];bcast(c.room)}
  else if(m.t==='emit'&&c.room&&typeof m.topic==='string'){
    c.room.forEach(o=>{if(o!==c)send(o,{t:'msg',topic:m.topic,data:m.data,from:c.id})})}}
srv.on('upgrade',(req,sock)=>{
  const key=req.headers['sec-websocket-key'];
  if(req.url.split('?')[0]!=='/ws'||!key){sock.destroy();return}
  sock.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: '+
    crypto.createHash('sha1').update(key+'258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64')+'\r\n\r\n');
  const c={sock,id:'p'+(nid++),pres:{},room:null,rn:null,dead:false};let buf=Buffer.alloc(0);
  send(c,{t:'hello',id:c.id});
  sock.on('data',d=>{buf=Buffer.concat([buf,d]);if(buf.length>200000){sock.destroy();return}
    while(buf.length>=2){
      let len=buf[1]&127,off=2;const op=buf[0]&15;
      if(len===126){if(buf.length<4)return;len=buf.readUInt16BE(2);off=4}
      else if(len===127){if(buf.length<10)return;len=Number(buf.readBigUInt64BE(2));off=10}
      const masked=buf[1]&128;if(masked)off+=4;
      if(len>65536){sock.destroy();return}
      if(buf.length<off+len)return;
      let pl=buf.slice(off,off+len);
      if(masked){const mk=buf.slice(off-4,off);pl=Buffer.from(pl.map((x,i)=>x^mk[i%4]))}
      buf=buf.slice(off+len);
      if(op===8){sock.end();return}
      if(op===9&&pl.length<126){sock.write(Buffer.concat([Buffer.from([0x8a,pl.length]),pl]));continue}
      if(op===1)handle(c,pl.toString())}});
  const bye=()=>{if(c.dead)return;c.dead=true;if(c.room){c.room.delete(c);if(!c.room.size)rooms.delete(c.rn);else bcast(c.room)}};
  sock.on('close',bye);sock.on('error',bye);
  c.ping=setInterval(()=>{if(!c.dead)try{sock.write(Buffer.from([0x89,0]))}catch(e){}},25000);
  sock.on('close',()=>clearInterval(c.ping));
});
srv.listen(process.env.PORT||3000,()=>console.log('Bola Cheia FC rodando na porta '+(process.env.PORT||3000)));
